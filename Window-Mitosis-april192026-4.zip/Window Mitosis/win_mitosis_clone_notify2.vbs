X=Msgbox("But you end up with more windows! Way more than you orignally had!",0+48,"...")
X=Msgbox("(You should`ve gone with Abort...)",0+16,"...")
X=Msgbox("Wait..",0+48,"...")
Dim var
var=Msgbox("You`re clicking the clone windows first instead of the main window, aren`t you?",4+32,"...")
If var=6 then
a=Msgbox("Hmph...",0+64,"...")
a=Msgbox("Everyone makes mistakes, even if they clearly know what to do.",0+64,"...")
Else
a=Msgbox("Oh.",0+64,"...")
a=Msgbox("Seems that you`ve gotten through everything already.",0+64,"...")
a=Msgbox("This is the most boring game of all time, didn`t i say?!",0+32,"...")
a=Msgbox("There`s too many windows already. Make it stop.",0+16,"...")
End if

