Dim var
Do until var=6
var=msgbox("I am the Quit Box. Click [Yes] to enter the quit menu! Move this window to a side or corner if you`re thinking of playing this for a long time. [Will ask for confirmation]",4+64,"The Quit Box")
loop

Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_exit.bat"