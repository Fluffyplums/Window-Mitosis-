X=MsgBox("Hello!",0+64,"...")
X=MsgBox("I`m the Quit Box! I`m here to help you when you have too many windows to close. I also work for faster exits!",0+64,"The Quit Box")
X=MsgBox("The reason I exist is because Task Manager doesn`t group the windows all into one program, thus you`ll have to close each box one by one.",0+64,"The Quit Box")
X=MsgBox("You`re welcome!",0+64,"The Quit Box")
Dim var
Do until var=6
var=msgbox("I am the Quit Box. Click [Yes] to quit! Move this window to a side or corner if you`re thinking of playing this for a long time. [Will ask for confirmation]",4+64,"The Quit Box")
loop

Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_exit.bat"