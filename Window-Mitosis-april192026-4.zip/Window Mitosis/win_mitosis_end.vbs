X=Msgbox("--*Window Mitosis*--",0+48,"Thanks for playing!")
X=Msgbox("Made by: Fluffleplum",0+48,"Thanks for playing!")
X=Msgbox("Made with: Notepad                                                                                                                                                                                Made in: Windows 10                                                                                                                                                                                        Languages used: Visual Basic and Batch",0+48,"Thanks for playing!")

X=Msgbox("Thank you for playing Window Mitosis!",0+48,"Thanks for playing!")
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_poster.png"