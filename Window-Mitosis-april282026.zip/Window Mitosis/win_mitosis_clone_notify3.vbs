X=Msgbox("Are there too many windows yet?",4+32,"...")
var=Msgbox("...Or are you here just to spite us?",4+32,"...")
