@echo off
color f
start "" "C:\Window Mitosis\win_mitosis_exitbox.vbs"
echo ---Window Mitosis---
echo *Close all windows? (Y/N)
echo  -The Quit Box is here in case you press the "X" button.
set /p input=
if /i %input%==N goto no
if /i %input%==Y goto accept1
if /i not %input%== Y,N goto confused

:confused
cls
color 8
echo ....Is that a yes?
pause
cls
color f
echo ---Window Mitosis---
echo *Close all windows? (Y/N)
echo  -The Quit Box is here in case you press the "X" button.
set /p input=
if /i %input%==N goto no
if /i %input%==Y goto accept1
if /i not %input%== Y,N goto confused



:no
cls
color a
echo ---Window Mitosis---
echo *Thanks for your answer.
pause
exit



:accept1
cls
color c
echo ---Window Mitosis---
echo *Are you sure you want to leave?
echo  -This will reset your progress, 
echo since the game doesn`t have a save system. (Y/N)
echo ---
set /p input=
if /i %input%==N goto no
if /i %input%==Y goto accept2
if /i not %input%== Y,N goto confused

:accept2
color 4
timeout 5
taskkill /IM wscript.exe /f
exit






