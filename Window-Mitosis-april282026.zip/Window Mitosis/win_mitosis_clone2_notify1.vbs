X=Msgbox("Wait!",0+48,"The Quit Box")
X=Msgbox("This is the same 5th section as before!",0+16,"The Quit Box")
X=Msgbox("But now it`s being used as a common enemy!",0+48,"The Quit Box")
X=Msgbox("No, no, no...",0+16,"The Quit Box")