X=Msgbox("...",0+48,"...")
X=Msgbox("...Nevermind.",0+64,"What?!")
X=Msgbox("I guess it really is endless.",0+64,"What?!")
