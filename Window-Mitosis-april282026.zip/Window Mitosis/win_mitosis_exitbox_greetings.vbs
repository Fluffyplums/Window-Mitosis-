X=MsgBox("Hello! (Click OK!)",0+0,"...")
X=MsgBox("I`m the Quit Box! I`m here to help you when you have too many windows to close.",0+64,"The Quit Box")
X=MsgBox("The reason I exist is because Task Manager doesn`t group the windows all into one program in older systems like Windows 10, thus you`ll have to close each box one by one.",0+64,"The Quit Box")
X=MsgBox("I also work for faster exits!",0+64,"The Quit Box")
X=MsgBox("I`m pretty sure you`ve already heard from the Command Prompt about that thing in the middle.",0+64,"The Quit Box")
X=MsgBox("Just... don`t click it too much.",0+64,"The Quit Box")
X=MsgBox("You`re welcome!",0+64,"The Quit Box")
Dim var
Do until var=6
var=msgbox("Hello! I am the Quit Box. Click [Yes] to enter the quit menu! Move this window to a side or corner if you`re thinking of playing this for a long time. [Will ask for confirmation]",4+64,"The Quit Box")
var=msgbox("Hello! I am the Quit Box. Click [Yes] again to enter the quit menu! Move this window to a side or corner if you`re thinking of playing this for a long time. [Will ask for confirmation]",4+64,"The Quit Box")
loop
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_exit.bat"