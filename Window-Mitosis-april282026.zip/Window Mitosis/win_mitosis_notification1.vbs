X=Msgbox("You`ve reached the 5th section of the error box!",4+48,"Oh no!  ")
X=Msgbox("Since when did that happen anyway?",0+32,"Oh no!  ")