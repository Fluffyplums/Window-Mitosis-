X=Msgbox("When will all of this end?",0+32,"Uhm... ")
X=Msgbox("I`m gonna guess that it`s like... 160 or something.",0+64,"Uhm...  ")
