@echo off
color 7
echo ---Window Mitosis---
echo *[WARNING: Please do not play for too long as too many windows may overload your system resources.]
echo --
echo -Loading the menu. Press any key to continue.
timeout /T 5 > NUL
cls
color f
echo ---Window Mitosis---
echo *[WARNING: Please do not play for too long as too many windows may overload your system resources.
echo --------------
echo *Are you sure you want to try this project? (Y/N)
echo -- 
echo *The only way you can stop the game is if you use the Quit Box to remove all windows. 
echo -You can say "N" or press Enter if you don`t want to make a mess on your computer yet.
echo ----
echo *Say "Read" to see the Readme file.
echo *Say "Info" to see how the game works.
echo --
set /p input=
if /i %input%==N goto two
if /i %input%==Y goto three
if /i %input%==Info goto one
if /i %input%==Read goto help
if /i %input%==Hello goto greetings
if /i not %input%== Y,N,Help,Info,Hello goto what

:what
cls
color 8
echo ...What?
echo --
pause
cls
color 7
echo ---Window Mitosis---
echo *[WARNING: Please do not play for too long as too many windows may overload your system resources.]
echo --
echo -Loading the menu. Press any key to continue.
timeout /T 5 > NUL
cls
color f
echo ---Window Mitosis---
echo *[WARNING: Please do not play for too long as too many windows may overload your system resources.
echo --------------
echo *Are you sure you want to try this project? (Y/N)
echo -- 
echo *The only way you can stop the game is if you use the Quit Box to remove all windows. 
echo -You can say "N" or press Enter if you don`t want to make a mess on your computer yet.
echo ----
echo *Say "Read" to see the Readme file.
echo *Say "Info" to see how the game works.
echo --
set /p input=
if /i %input%==N goto two
if /i %input%==Y goto three
if /i %input%==Info goto one
if /i %input%==Read goto help
if /i %input%==Hello goto greetings
if /i not %input%== Y,N,Help,Info,Hello goto what



:greetings
cls
color 9
echo Hello?
echo --
pause
cls
color 7
echo ---Window Mitosis---
echo *[WARNING: Please do not play for too long as too many windows may overload your system resources.]
echo --
echo -Loading the menu. Press any key to continue.
timeout /T 5 > NUL
cls
color f
echo ---Window Mitosis---
echo *[WARNING: Please do not play for too long as too many windows may overload your system resources.
echo --------------
echo *Are you sure you want to try this project? (Y/N)
echo -- 
echo *The only way you can stop the game is if you use the Quit Box to remove all windows. 
echo -You can say "N" or press Enter if you don`t want to make a mess on your computer yet.
echo ----
echo *Say "Read" to see the Readme file.
echo *Say "Info" to see how the game works.
echo --
set /p input=
if /i %input%==N goto two
if /i %input%==Y goto three
if /i %input%==Info goto one
if /i %input%==Read goto help
if /i %input%==Hello goto greetings
if /i not %input%== Y,N,Help,Info,Hello goto what

:two
cls
color a
echo ---Window Mitosis---
echo  -Thanks for your answer.
pause
exit

:three
cls
color c
echo ---Window Mitosis---
echo  -Remember, you can only stop this game by closing every window using the Quit Box!
timeout 5
start "" "C:Window Mitosis\win_mitosis_2.vbs"
start "" "C:\Window Mitosis\win_mitosis_exitbox_greetings.vbs"
exit


:one
color 7
timeout /T 1 > NUL
start "" "C:\Window Mitosis\win_mitosis_info.vbs"
color f
pause
set /p input=
if /i %input%==N goto two
if /i %input%==Y goto three
if /i %input%==Info goto one
if /i %input%==Read goto help
if /i %input%==Hello goto greetings
if /i not %input%== Y,N,Help,Info,Hello goto what



:help
color 7
timeout /T 1 > NUL
start "" "C:\Window Mitosis\readmefirst.txt"
color f
pause
set /p input=
if /i %input%==N goto two
if /i %input%==Y goto three
if /i %input%==Info goto one
if /i %input%==Read goto help
if /i %input%==Hello goto greetings
if /i not %input%== Y,N,Help,Info,Hello goto what






