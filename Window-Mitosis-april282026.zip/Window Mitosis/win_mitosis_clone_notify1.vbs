X=Msgbox("You try to go through the rest.",0+64,"...")
X=Msgbox("It goes over, and over...                                                                        ...And over again.",0+64,"...")
X=Msgbox("And yet you remember (or are trying to remember) what`s going on.",0+64,"...")