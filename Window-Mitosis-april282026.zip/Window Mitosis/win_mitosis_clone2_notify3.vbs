X=Msgbox("I give up.",0+16,"The Quit Box")
X=Msgbox("You didn`t hear from my previous warning...",0+16,"The Quit Box")
X=Msgbox("Maybe you want to end this game once and for all.",0+64,"The Quit Box")
X=Msgbox("...",0+0,"The Quit Box")
Dim var
var=Msgbox("But are you sure it`s worth it?",4+32,"The Quit Box")
var=Msgbox("Really?",4+32,"The Quit Box")
If var=6 then
X=Msgbox("No, it`s not.",0+16,"The Quit Box")
X=Msgbox("But what if a nice end screen is enough?",0+32,"The Quit Box")
X=Msgbox("I mean, in your view, it probably IS worth it.",0+64,"The Quit Box")
X=Msgbox("They tell me to believe in myself, and that things would be better.",0+64,"The Quit Box")
X=Msgbox("And think YOU should do that too.",0+48,"The Quit Box")
Else
X=Msgbox("I`m thinking the exact same...",0+64,"The Quit Box")
X=Msgbox("Yes, it really isn`t.",0+16,"The Quit Box")
X=Msgbox("All you do is the click a window with a number on it.",0+16,"The Quit Box")
X=Msgbox("There`s no rewards after all...",0+16,"The Quit Box")
End if
