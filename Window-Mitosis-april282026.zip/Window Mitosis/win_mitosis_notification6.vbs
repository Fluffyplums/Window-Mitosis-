eX=Msgbox("After all that clicking...",0+64,"Congratulations!")
X=Msgbox("You`ve closed all 20 sections!",4+48,"Congratulations!")
X=Msgbox("You won the game!                                                                                                                                                                                 -The most boring game of all time!",4+48,"Congratulations!")
X=Msgbox("You won, right?",4+32,"Congratulations!")
X=Msgbox("...Right?",4+32,"Congratulations?")
Dim Y
Y=Msgbox("But it left one too many windows.                                                                                                                                                        -And now, to go with the rest...",2+16,"Congratulations?")
if Y=3 then
a=MsgBox("You knew that all of these windows have the same purpose, as said from the start.",0+48,"Abort")
a=MsgBox("So to avoid spreading the boxes even more...",0+64,"Abort")
a=MsgBox("You finally decide to quit out of the game.",0+48,"Abort")
a=MsgBox("But maybe you`ll play this another time.",4+64,"Abort")
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_end.vbs"
elseif Y=4 then
a=MsgBox("Even if you know what these boxes are capable of, you`re still here for more.",0+64,"Retry")
a=MsgBox("-So you decide to waste more of your time clicking a window with a number on it.",0+64,"Retry")
elseif Y=5 then
a=MsgBox("You decide to ignore everything and try to close all of the remaining windows.",0+16,"Ignore")
a=MsgBox("'We can just go through all the rest!', you think.",0+16,"Ignore")
a=MsgBox("Who knows what could happen?",0+16,"Ignore")
end if

