X=Msgbox("...",0+0,"The Quit Box")
X=Msgbox("Is it over?",4+0,"The Quit Box")
X=Msgbox("Is it actually over?",4+0,"The Quit Box")
X=Msgbox("Hmm.",0+64,"The Quit Box")
X=Msgbox("Didn`t know it would end THAT fast.",0+64,"The Quit Box")
X=Msgbox("I can`t believe you didn`t give up at this point.",0+64,"The Quit Box")
X=Msgbox("As much as i desperately {CRAVE} the ending of this madness...",0+16,"The Quit Box")
X=Msgbox("I`m somehow proud.",0+64,"The Quit Box")
X=Msgbox("It`s like you`ve done a favor for us.",0+64,"The Quit Box")
X=Msgbox("But at the same time...",0+48,"The Quit Box")
X=Msgbox("You made lots of other threats from clicking more windows, now there`s too many!                                                                                                                                                                                -But maybe it`s our fault for leaving you to click it in the first place.",0+16,"The Quit Box")
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_ending1.vbs"

