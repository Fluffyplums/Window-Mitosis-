X=Msgbox("[You stopped spreading the chaos.]",0+64,"[Good(?) Ending]")
X=Msgbox("--*Window Mitosis*--",0+48,"Thanks for playing!")
X=Msgbox("Made by: Fluffleplum",0+48,"Thanks for playing!")
X=Msgbox("Made in: Notepad",0+48,"Thanks for playing!")
X=Msgbox("Made with: Visual Basic & Batch",0+48,"Thanks for playing!")
X=Msgbox("Operating system used: Windows 10",0+48,"Thanks for playing!")
X=Msgbox("Thank you for playing Window Mitosis!",0+48,"Thanks for playing!")
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_poster.png"