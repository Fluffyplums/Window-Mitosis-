X=Msgbox("You`ve reached the end once again.",4+48,"...")
X=Msgbox("Or rather, the end of this window.",0+64,"...")
X=Msgbox("So close, yet so far.",0+64,"...")
X=Msgbox("(You look at your screen, where a corner has a pile of boxes.)",0+64,"...")
X=Msgbox("(Boxes that you haven`t opened.)",0+64,"...")
X=Msgbox("(And a box that`s completely different from the rest tells you if you want to open another one.)",0+64,"...")
X=Msgbox("(But it doesn`t want you to do so.)",0+64,"...")
Dim var
var=Msgbox("Now, are you really gonna do this again? Don`t tell me i didn`t warn you.",4+64,"...")
if var=7 then
a=Msgbox("Thank goodness...",0+64,"...")
a=Msgbox("I was getting really worried there.",0+64,"...")
a=Msgbox("By the way, i`m actually just that box in the corner talking to you.",0+64,"The Quit Box")
a=Msgbox("I`m not a button sitting there watching as you slowly fork bomb your desktop with more and more boxes.",0+64,"The Quit Box")
a=Msgbox("Crazy, right?",4+64,"The Quit Box")
a=Msgbox("Anyways, cue the end credits again!",0+64,"The Quit Box")
a=Msgbox("(I wonder why we have to show them a second time?)",0+64,"The Quit Box")
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_end.vbs"
else
a=Msgbox("Sigh.",0+64,"...")
a=Msgbox("I really didn`t want this.",0+64,"...")
a=Msgbox("I really, REALLY didn`t want this...",0+64,"...")
a=Msgbox("I was hoping you could finally click [Yes] and move on.",0+64,"The Quit Box")
a=Msgbox("Now we have to watch it happen again.",0+64,"The Quit Box")
a=Msgbox("Again, and again...",0+64,"The Quit Box")
a=Msgbox("...until your computer crashes.",0+64,"The Quit Box")
a=Msgbox("Considering how small those things are, it`s gonna take a very, VERY long time.",4+64,"The Quit Box")
a=Msgbox("...Now, cue the end credits please...",0+64,"The Quit Box")
a=Msgbox("...",0+64,"The Quit Box")
a=Msgbox("Please.",0+64,"The Quit Box")
Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.Run "win_mitosis_end.vbs"
end if




